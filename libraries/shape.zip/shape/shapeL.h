 #ifndef __SHAPE_L_H_INCLUDED__
 #define __SHAPE_L_H_INCLUDED__
#include "shape.h"
class shapeL : public shape {
  public:
     
     void startShape();
     void rotateShape();
};
#endif
